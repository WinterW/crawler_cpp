<?php
phpinfo();
//echo "a";
?>
